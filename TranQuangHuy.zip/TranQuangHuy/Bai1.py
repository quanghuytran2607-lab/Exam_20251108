def check(num):
	if num==0:
		print(num, "là số 0")
	elif num>0:
		print(num, "là số dương")
	else:
		print(num, "là số âm")

a = int(input())
check(a)