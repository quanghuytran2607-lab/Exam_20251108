n = int(input())
if n<=0:
	t=0
elif n>0 and n<=100:
	t = n*2000
elif n>100 and n<=200:
	t = 2000*100 + (n-100) * 3000
else:
	t = 2000*100 + 3000 * 100 + (n-200) * 4000
print("Tiền điện phải trả là", t, "đồng")