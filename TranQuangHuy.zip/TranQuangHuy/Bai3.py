def check(tuoi):
	if tuoi<12:
		print("Trẻ em")
	elif tuoi>=12 and tuoi <=17:
		print("Thiếu niên")
	elif tuoi>=18 and tuoi <60:
		print("Người trưởng thành")
	else:
		print("Người cao tuổi")

a = int(input())
check(a)