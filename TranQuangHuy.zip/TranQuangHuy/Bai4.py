def check(t):
	if t<5:
		print("Hạng D")
	elif t>=5 and t <7:
		print("Hạng C")
	elif t>=7 and t <8.5:
		print("Hạng B")
	else:
		print("Hạng A")

a = float(input())
check(a)