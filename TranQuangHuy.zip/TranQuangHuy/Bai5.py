def check(t):
	if t<18.5:
		print("Gầy")
	elif t>=18.5 and t <25:
		print("Bình thường")
	elif t>=25 and t <29.9:
		print("Thừa cân")
	else:
		print("Béo phì")

a = float(input("Nhập cân nặng(kg): "))
b = float(input("Nhập chiều cao(m): "))

bmi = a / (b**2)

check(bmi)